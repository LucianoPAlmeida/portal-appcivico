"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
var application_model_1 = require('../model/application.model');
var urlprovider_service_1 = require('./urlprovider.service');
var ApplicationService = (function () {
    function ApplicationService(http) {
        this.http = http;
        // appsURL: string = "http://mobile-aceite.tcu.gov.br/appCivicoRS/rest/aplicativos";
        this.urlProvider = new urlprovider_service_1.URLProvider();
    }
    ApplicationService.prototype.getApps = function (codOwner) {
        return this.http.get(this.getAppOwnerURL(codOwner)).map(function (response) {
            var body = response.json();
            var apps = [];
            for (var _i = 0, body_1 = body; _i < body_1.length; _i++) {
                var jsonApp = body_1[_i];
                var app = new application_model_1.Application();
                app.cod = Number(jsonApp['cod']);
                app.name = jsonApp['nome'];
                app.description = jsonApp['descricao'];
                apps.push(app);
            }
            return apps;
        });
    };
    ApplicationService.prototype.registerApp = function (appToken, codOwner, app) {
        var headers = new http_1.Headers({ 'appToken': appToken });
        return this.http.post(this.urlProvider.appsURL(), { codResponsavel: codOwner, nome: app.name, descricao: app.description }, { headers: headers }).map(function (response) {
            var location = response.headers.get('Location');
            var parts = location.split('/');
            return (parts.length > 0) ? +parts[parts.length - 1] : null;
        });
    };
    ApplicationService.prototype.updateApp = function (appToken, codOwner, app) {
        var url = this.urlProvider.appCodURL(app.cod);
        var headers = new http_1.Headers({ 'appToken': appToken });
        return this.http.put(url, { codResponsavel: codOwner, nome: app.name, descricao: app.description }, { headers: headers });
    };
    ApplicationService.prototype.getAppOwnerURL = function (codOwner) {
        return this.urlProvider.appsOwnerURL(codOwner);
    };
    ApplicationService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], ApplicationService);
    return ApplicationService;
}());
exports.ApplicationService = ApplicationService;
//# sourceMappingURL=application.service.js.map