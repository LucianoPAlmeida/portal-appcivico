"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
var typeprofile_model_1 = require('../model/typeprofile.model');
var urlprovider_service_1 = require('./urlprovider.service');
var ProfileTypeService = (function () {
    function ProfileTypeService(http) {
        this.http = http;
        this.urlProvider = new urlprovider_service_1.URLProvider();
    }
    ProfileTypeService.prototype.registerProfileTypesForApp = function (token, appCod, profileType) {
        var headers = new http_1.Headers({ 'appToken': token });
        return this.http.post(this.urlProvider.profileTypesForAppURL(appCod), { descricao: profileType.description }, { headers: headers }).map(function (response) {
            var location = response.headers.get('Location');
            var array = location.split('/');
            return +array[array.length - 1];
        });
    };
    ProfileTypeService.prototype.updateProfileTypeForApp = function (token, profileType) {
        var headers = new http_1.Headers({ 'appToken': token });
        return this.http.put(this.urlProvider.profileTypesURL(profileType.codApp, profileType.cod), { descricao: profileType.description }, { headers: headers }).map(function (response) {
            return;
        });
    };
    ProfileTypeService.prototype.deleteProfileTypeForApp = function (token, appCod, profileType) {
        var headers = new http_1.Headers({ 'appToken': token });
        return this.http.delete(this.urlProvider.profileTypesURL(appCod, profileType.cod)).map(function (response) {
            return;
        });
    };
    ProfileTypeService.prototype.getProfileTypesForApp = function (appCod) {
        var _this = this;
        return this.http.get(this.urlProvider.profileTypesForAppURL(appCod)).map(function (response) {
            var body = response.json();
            var profiles = [];
            for (var _i = 0, body_1 = body; _i < body_1.length; _i++) {
                var json = body_1[_i];
                profiles.push(_this.jsonToProfileType(json));
            }
            return profiles;
        });
    };
    ProfileTypeService.prototype.jsonToProfileType = function (json) {
        var profileType = new typeprofile_model_1.TypeProfile();
        profileType.cod = json['codTipoPerfil'];
        profileType.description = json['descricao'];
        profileType.codApp = this.locationCodeFromJson(json, 'aplicativo');
        return profileType;
    };
    ProfileTypeService.prototype.locationCodeFromJson = function (json, rel) {
        var links = json['links'];
        for (var _i = 0, links_1 = links; _i < links_1.length; _i++) {
            var link = links_1[_i];
            if (link['rel'] == rel) {
                var location = link['href'];
                var array = location.split('/');
                return +array[array.length - 1];
            }
        }
        return null;
    };
    ProfileTypeService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], ProfileTypeService);
    return ProfileTypeService;
}());
exports.ProfileTypeService = ProfileTypeService;
//# sourceMappingURL=profiletype.service.js.map