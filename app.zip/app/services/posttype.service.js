"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
var typepost_model_1 = require('../model/typepost.model');
var urlprovider_service_1 = require('./urlprovider.service');
var PostTypeService = (function () {
    function PostTypeService(http) {
        this.http = http;
        this.urlProvider = new urlprovider_service_1.URLProvider();
    }
    // postTypesURL : string = "http://mobile-aceite.tcu.gov.br:/";
    PostTypeService.prototype.postTypesForApp = function (codApp) {
        var _this = this;
        return this.http.get(this.urlProvider.postTypesForApplicationURL(codApp)).map(function (response) {
            var body = response.json();
            var types = [];
            for (var _i = 0, body_1 = body; _i < body_1.length; _i++) {
                var json = body_1[_i];
                types.push(_this.jsonToPost(json));
            }
            return types;
        });
    };
    PostTypeService.prototype.jsonToPost = function (json) {
        var typePost = new typepost_model_1.TypePost();
        typePost.cod = json['cod'];
        typePost.description = json['descricao'];
        typePost.contentDescription = json['textoFormatoJson'];
        typePost.codDestinationObjType = json['codTipoObjetoDestino'];
        typePost.codRelatedPostType = this.codParentTypeFromJson(json);
        typePost.codApp = this.codAppFromJson(json);
        return typePost;
    };
    PostTypeService.prototype.registerNewPostType = function (token, typePost) {
        var headers = new http_1.Headers({ 'appToken': token });
        var body = this.bodyFromTypePost(typePost);
        return this.http.post(this.urlProvider.postTypeURL(), body, { headers: headers }).map(function (response) {
            var location = response.headers.get('Location');
            var array = location.split('/');
            return +array[array.length - 1];
        });
    };
    PostTypeService.prototype.updatePostType = function (token, typePost) {
        var headers = new http_1.Headers({ 'appToken': token });
        var body = this.bodyFromTypePost(typePost);
        return this.http.put(this.urlProvider.postTypeCodURL(typePost.cod), body, { headers: headers }).map(function (response) {
            return;
        });
    };
    PostTypeService.prototype.deletePostType = function (token, typePostCod) {
        return this.http.delete(this.urlProvider.postTypeCodURL(typePostCod)).map(function (response) {
            return;
        });
    };
    // MARK: Convenience methods
    PostTypeService.prototype.bodyFromTypePost = function (typePost) {
        var body = { codAplicativo: typePost.codApp, descricao: typePost.description, codTipoObjetoDestino: typePost.codDestinationObjType };
        if (typePost.codRelatedPostType) {
            body['codTipoPostagemPai'] = typePost.codRelatedPostType;
        }
        if (typePost.contentDescription) {
            body['textoFormatoJson'] = typePost.contentDescription;
        }
        return body;
    };
    PostTypeService.prototype.codParentTypeFromJson = function (json) {
        return this.locationCodeFromJson(json, 'tipoPostagemPai');
    };
    PostTypeService.prototype.codAppFromJson = function (json) {
        return this.locationCodeFromJson(json, 'aplicativo');
    };
    PostTypeService.prototype.locationCodeFromJson = function (json, rel) {
        var links = json['links'];
        for (var _i = 0, links_1 = links; _i < links_1.length; _i++) {
            var link = links_1[_i];
            if (link['rel'] == rel) {
                var location = link['href'];
                var array = location.split('/');
                return +array[array.length - 1];
            }
        }
        return null;
    };
    PostTypeService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], PostTypeService);
    return PostTypeService;
}());
exports.PostTypeService = PostTypeService;
//# sourceMappingURL=posttype.service.js.map