"use strict";
var URLProvider = (function () {
    function URLProvider() {
        this.productionDomain = "http://mobile-aceite.tcu.gov.br";
        this.localDomain = "http://localhost:8080";
        this.serverDomain = this.localDomain;
    }
    //Aplicativos
    URLProvider.prototype.appsURL = function () {
        return this.serverDomain + "/appCivicoRS/rest/aplicativos";
    };
    URLProvider.prototype.appCodURL = function (codApp) {
        return this.appsURL() + '/' + codApp;
    };
    URLProvider.prototype.appsOwnerURL = function (codOwner) {
        return this.appsURL() + '/pessoa/' + codOwner;
    };
    //Tipos de Postagem
    URLProvider.prototype.postTypeURL = function () {
        return this.serverDomain + '/appCivicoRS/rest/tipos-postagem';
    };
    URLProvider.prototype.postTypeCodURL = function (cod) {
        return this.postTypeURL() + '/' + cod;
    };
    URLProvider.prototype.postTypesForApplicationURL = function (codApp) {
        return this.postTypeURL() + '/aplicativo/' + codApp;
    };
    //Tipos de perfil
    URLProvider.prototype.profileTypesForAppURL = function (appCod) {
        return this.appCodURL(appCod) + "/tipos-perfil";
    };
    URLProvider.prototype.profileTypesURL = function (appCod, typeCod) {
        return this.profileTypesForAppURL(appCod) + "/" + typeCod;
    };
    //Pessoas
    URLProvider.prototype.personURL = function () {
        return this.serverDomain + '/appCivicoRS/rest/pessoas';
    };
    URLProvider.prototype.personAuthURL = function () {
        return this.personURL() + '/autenticar';
    };
    URLProvider.prototype.forgetPasswordURL = function () {
        return this.personURL() + '/redefinirSenha';
    };
    URLProvider.prototype.personProfileURL = function (codPerson) {
        return this.personURL() + '/' + codPerson + '/perfil';
    };
    //Tipos de objeto
    URLProvider.prototype.objectTypeURL = function () {
        return this.serverDomain + '/appCivicoRS/rest/tipos-objeto';
    };
    //Hashtags
    URLProvider.prototype.hashtagsURL = function () {
        return this.serverDomain + '/appCivicoRS/rest/hashtags';
    };
    URLProvider.prototype.hashtagsCodURL = function (cod) {
        return this.hashtagsURL() + '/' + cod;
    };
    URLProvider.prototype.hashtagsForApp = function (appCod) {
        return this.appCodURL(appCod) + '/hashtags';
    };
    return URLProvider;
}());
exports.URLProvider = URLProvider;
//# sourceMappingURL=urlprovider.service.js.map