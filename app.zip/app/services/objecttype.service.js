"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
var objecttype_model_1 = require('../model/objecttype.model');
var urlprovider_service_1 = require('./urlprovider.service');
var ObjectTypeService = (function () {
    function ObjectTypeService(http) {
        this.http = http;
        this.urlProvider = new urlprovider_service_1.URLProvider();
    }
    ObjectTypeService.prototype.objectTypes = function () {
        var _this = this;
        return this.http.get(this.urlProvider.objectTypeURL()).map(function (response) {
            var body = response.json();
            var objTypes = [];
            for (var _i = 0, body_1 = body; _i < body_1.length; _i++) {
                var json = body_1[_i];
                objTypes.push(_this.jsonToObjectType(json));
            }
            return objTypes;
        });
    };
    ObjectTypeService.prototype.jsonToObjectType = function (json) {
        var objType = new objecttype_model_1.ObjectType();
        objType.cod = json['cod'];
        objType.description = json['descricao'];
        return objType;
    };
    ObjectTypeService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], ObjectTypeService);
    return ObjectTypeService;
}());
exports.ObjectTypeService = ObjectTypeService;
//# sourceMappingURL=objecttype.service.js.map