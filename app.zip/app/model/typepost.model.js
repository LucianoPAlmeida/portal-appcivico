"use strict";
var TypePost = (function () {
    function TypePost() {
    }
    TypePost.prototype.clone = function () {
        var newTypePost = new TypePost();
        newTypePost.cod = this.cod;
        newTypePost.description = this.description;
        newTypePost.codRelatedPostType = this.codRelatedPostType;
        newTypePost.codDestinationObjType = this.codDestinationObjType;
        newTypePost.codApp = this.codApp;
        newTypePost.contentDescription = this.contentDescription;
        return newTypePost;
    };
    return TypePost;
}());
exports.TypePost = TypePost;
//# sourceMappingURL=typepost.model.js.map