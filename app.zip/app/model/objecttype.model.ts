export /**
 * ObjectType
 */
class ObjectType {

    cod: number;
    description: string;

    constructor() {}
    
}