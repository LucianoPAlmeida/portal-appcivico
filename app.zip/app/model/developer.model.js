"use strict";
var Developer = (function () {
    function Developer() {
    }
    return Developer;
}());
exports.Developer = Developer;
//# sourceMappingURL=developer.model.js.map