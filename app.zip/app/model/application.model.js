"use strict";
var Application = (function () {
    function Application() {
    }
    Application.prototype.clone = function () {
        var newApp = new Application();
        newApp.cod = this.cod;
        newApp.name = this.name;
        newApp.description = this.description;
        return newApp;
    };
    return Application;
}());
exports.Application = Application;
//# sourceMappingURL=application.model.js.map