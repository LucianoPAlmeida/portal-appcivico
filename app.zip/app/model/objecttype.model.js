"use strict";
var ObjectType = (function () {
    function ObjectType() {
    }
    return ObjectType;
}());
exports.ObjectType = ObjectType;
//# sourceMappingURL=objecttype.model.js.map