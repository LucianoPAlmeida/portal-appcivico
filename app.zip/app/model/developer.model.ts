
export class Developer{
    
    cod: number;
    name: string;
    email: string;
    genre: string;
    about: string;
    password: string;
    
    constructor() {}

}