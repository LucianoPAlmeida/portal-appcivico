"use strict";
var UserSession = (function () {
    function UserSession(token, developer) {
        this.token = token;
        this.currentDeveloper = developer;
    }
    return UserSession;
}());
exports.UserSession = UserSession;
//# sourceMappingURL=usersession.model.js.map