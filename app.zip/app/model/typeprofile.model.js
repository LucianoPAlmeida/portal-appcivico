"use strict";
var TypeProfile = (function () {
    function TypeProfile() {
    }
    TypeProfile.prototype.clone = function () {
        var newType = new TypeProfile();
        newType.cod = this.cod;
        newType.description = this.description;
        newType.codApp = this.codApp;
        return newType;
    };
    return TypeProfile;
}());
exports.TypeProfile = TypeProfile;
//# sourceMappingURL=typeprofile.model.js.map