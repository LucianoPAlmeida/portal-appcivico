"use strict";
var router_1 = require('@angular/router');
var login_component_1 = require('../components/login/login.component');
var register_component_1 = require('../components/register/register.component');
var listapp_component_1 = require('../components/listapp/listapp.component');
var listprofiles_component_1 = require('../components/listprofiles/listprofiles.component');
var listposttypes_component_1 = require('../components/listposttypes/listposttypes.component');
var principal_component_1 = require('../components/principal/principal.component');
var listhashtags_component_1 = require('../components/listhashtags/listhashtags.component');
var routes = [
    { path: '', component: principal_component_1.PrincipalComponent },
    { path: 'login', component: login_component_1.LoginComponent },
    { path: 'cadastro', component: register_component_1.RegisterComponent },
    { path: 'principal', component: principal_component_1.PrincipalComponent },
    { path: 'aplicativos', component: listapp_component_1.ListAppsComponent },
    { path: 'tipos-de-perfil', component: listprofiles_component_1.ListProfiles },
    { path: 'tipos-de-postagem', component: listposttypes_component_1.ListPostTypes },
    { path: 'hashtags', component: listhashtags_component_1.ListHashtags }
];
exports.appRouterProviders = [
    router_1.provideRouter(routes)
];
//# sourceMappingURL=app.routes.js.map