"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require('../../services/user.service');
var core_2 = require('angular2-cookie/core');
var http_1 = require('@angular/http');
var NavigationComponent = (function () {
    function NavigationComponent(userService, router) {
        this.userService = userService;
        this.router = router;
    }
    NavigationComponent.prototype.ngOnInit = function () {
        if (!this.userService.hasAuthenticatedUser()) {
            this.router.navigate(['/login']);
        }
        else {
            this.developerEmail = this.userService.currentSession().currentDeveloper.email;
            this.developerName = this.userService.currentSession().currentDeveloper.name;
        }
    };
    NavigationComponent.prototype.logOutClick = function () {
        this.userService.logOut();
        this.router.navigate(['/login']);
    };
    NavigationComponent = __decorate([
        core_1.Component({
            selector: 'navigation-bar',
            templateUrl: 'app/components/navigation/navigation.component.html',
            directives: [router_1.ROUTER_DIRECTIVES],
            providers: [user_service_1.UserService, core_2.CookieService, http_1.HTTP_PROVIDERS]
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService, router_1.Router])
    ], NavigationComponent);
    return NavigationComponent;
}());
exports.NavigationComponent = NavigationComponent;
//# sourceMappingURL=navigation.component.js.map