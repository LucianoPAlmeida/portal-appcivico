"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var application_service_1 = require('../../services/application.service');
var user_service_1 = require('../../services/user.service');
var http_1 = require('@angular/http');
var core_2 = require('angular2-cookie/core');
var navigation_component_1 = require('../navigation/navigation.component');
var appform_component_1 = require('../appform/appform.component');
var loading_component_1 = require('../loading/loading.component');
var ListAppsComponent = (function (_super) {
    __extends(ListAppsComponent, _super);
    function ListAppsComponent(userService, appservice, router) {
        _super.call(this, false);
        this.userService = userService;
        this.appservice = appservice;
        this.router = router;
        this.apps = [];
        this.isLoaded = false;
        this.errorMessage = null;
    }
    ListAppsComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.userService.hasAuthenticatedUser()) {
            this.router.navigate(['/login']);
        }
        else {
            this.standby();
            this.appservice.getApps(this.userService.currentSession().currentDeveloper.cod).subscribe(function (apps) {
                _this.ready();
                _this.isLoaded = true;
                _this.apps = apps;
                _this.apps = _this.apps.sort(function (a, b) {
                    return a.cod - b.cod;
                });
            }, function (error) {
                _this.ready();
                _this.errorMessage = "Houve um erro ao carregar os aplicativos. Verifique sua conexão com a internet e recarregue a página.";
            });
        }
    };
    ListAppsComponent.prototype.selectApp = function (app) {
        this.appForm.currentApplication = app.clone();
        this.appForm.isUpdating = true;
    };
    ListAppsComponent.prototype.newAppClickAction = function () {
        this.appForm.newApp();
    };
    ListAppsComponent.prototype.registerNewApp = function (app) {
        this.apps.push(app);
    };
    ListAppsComponent.prototype.updateApp = function (app) {
        for (var i = 0; i < this.apps.length; i += 1) {
            if (app.cod == this.apps[i].cod) {
                this.apps[i] = app;
            }
        }
    };
    __decorate([
        core_1.ViewChild(navigation_component_1.NavigationComponent), 
        __metadata('design:type', navigation_component_1.NavigationComponent)
    ], ListAppsComponent.prototype, "navComponent", void 0);
    __decorate([
        core_1.ViewChild(appform_component_1.ApplicationForm), 
        __metadata('design:type', appform_component_1.ApplicationForm)
    ], ListAppsComponent.prototype, "appForm", void 0);
    ListAppsComponent = __decorate([
        core_1.Component({
            selector: 'list-apps',
            templateUrl: 'app/components/listapp/listapp.component.html',
            providers: [user_service_1.UserService, application_service_1.ApplicationService, http_1.HTTP_PROVIDERS, core_2.CookieService],
            directives: [router_1.ROUTER_DIRECTIVES, navigation_component_1.NavigationComponent, appform_component_1.ApplicationForm, loading_component_1.LoadingIndicator]
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService, application_service_1.ApplicationService, router_1.Router])
    ], ListAppsComponent);
    return ListAppsComponent;
}(loading_component_1.LoadingPage));
exports.ListAppsComponent = ListAppsComponent;
//# sourceMappingURL=listapp.component.js.map