"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require('../../services/user.service');
var router_1 = require('@angular/router');
var core_2 = require('angular2-cookie/core');
var http_1 = require('@angular/http');
var posttype_service_1 = require('../../services/posttype.service');
var typepost_model_1 = require('../../model/typepost.model');
var loading_component_1 = require('../loading/loading.component');
var objecttype_service_1 = require('../../services/objecttype.service');
var PostTypeForm = (function (_super) {
    __extends(PostTypeForm, _super);
    function PostTypeForm(postService, userService, router, objService) {
        _super.call(this, false);
        this.postService = postService;
        this.userService = userService;
        this.router = router;
        this.objService = objService;
        this.errorMessage = null;
        this.sucessMessage = null;
        this.currentPostType = new typepost_model_1.TypePost();
        this.selectedParentPostType = null;
        this.isUpdating = false;
        this.isLoadingParents = false;
        this.register = new core_1.EventEmitter();
        this.update = new core_1.EventEmitter();
    }
    PostTypeForm.prototype.ngOnInit = function () {
        var _this = this;
        this.objService.objectTypes().subscribe(function (objectTypes) {
            _this.objectTypes = objectTypes;
        }, function (error) {
            _this.errorMessage = 'Ocorreu um erro  e não foi possivel buscar os tipos de objeto disponíveis. Recarregue a página para tentar novamente';
        });
    };
    PostTypeForm.prototype.clear = function () {
        this.currentPostType.description = "";
        this.selectedParentPostType = null;
        this.selectedObjType = null;
    };
    PostTypeForm.prototype.newTypePost = function () {
        this.isUpdating = false;
        this.clear();
        this.currentPostType = new typepost_model_1.TypePost();
        this.selectedApp = null;
    };
    PostTypeForm.prototype.onSubmit = function () {
        if (this.isUpdating) {
            this.updatePostType();
        }
        else {
            this.registerPostType();
        }
    };
    PostTypeForm.prototype.changeAppAction = function (app) {
        var _this = this;
        this.hideErrorMessage();
        this.postService.postTypesForApp(app.cod).subscribe(function (types) {
            _this.postTypes = types;
            if (_this.isUpdating) {
                _this.removeCurrentFromPostTypes();
            }
        }, function (error) {
            _this.showErrorMessage('Falha ao carregar tipos de postagem para o aplicativo. Verifique sua conexão com a internet e recarregue a página.');
        });
    };
    PostTypeForm.prototype.registerPostType = function () {
        var _this = this;
        this.standby();
        this.currentPostType.codApp = this.selectedApp.cod;
        this.currentPostType.codRelatedPostType = (this.selectedParentPostType) ? this.selectedParentPostType.cod : null;
        this.currentPostType.codDestinationObjType = (this.selectedObjType) ? this.selectedObjType.cod : null;
        console.log(this.currentPostType);
        this.postService.registerNewPostType(this.userService.currentSession().token, this.currentPostType).subscribe(function (cod) {
            _this.ready();
            _this.currentPostType.cod = cod;
            _this.showSuccessMessage('Tipo de postagem registrada com sucesso. O código do tipo de postagem é o \"' + cod + '\". Esse será o código que você irá usar como parâmetro nos endpoints da plataforma.');
            _this.register.emit(_this.currentPostType.clone());
            _this.newTypePost();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe um tipo de postagem com esse nome cadastrada para esse aplicativo');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar o cadastro. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    PostTypeForm.prototype.updatePostType = function () {
        var _this = this;
        this.standby();
        this.currentPostType.codRelatedPostType = (this.selectedParentPostType) ? this.selectedParentPostType.cod : null;
        this.currentPostType.codDestinationObjType = (this.selectedObjType) ? this.selectedObjType.cod : null;
        this.postService.updatePostType(this.userService.currentSession().token, this.currentPostType).subscribe(function () {
            _this.ready();
            _this.showSuccessMessage('Tipo de postagem alterada com sucesso');
            _this.update.emit(_this.currentPostType.clone());
            _this.newTypePost();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe um tipo de postagem com esse nome cadastrada para esse aplicativo');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar o cadastro. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    PostTypeForm.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    PostTypeForm.prototype.hideErrorMessage = function () {
        this.errorMessage = null;
    };
    PostTypeForm.prototype.hideSucessMessage = function () {
        this.sucessMessage = null;
    };
    PostTypeForm.prototype.hideMessages = function () {
        this.hideErrorMessage();
        this.hideSucessMessage();
    };
    PostTypeForm.prototype.showSuccessMessage = function (message) {
        this.sucessMessage = message;
    };
    PostTypeForm.prototype.clearParentSelect = function () {
        this.selectedParentPostType = null;
    };
    PostTypeForm.prototype.setUpdatePostForm = function (postType, typesForApp, apps) {
        this.postTypes = typesForApp;
        this.apps = apps;
        this.isUpdating = true;
        this.currentPostType = postType;
        this.selectedApp = this.appForCode(postType.codApp);
        this.selectedParentPostType = this.parentTypeForCode(postType.codRelatedPostType);
        this.selectedObjType = this.objectTypeForCode(postType.codDestinationObjType);
    };
    PostTypeForm.prototype.appForCode = function (cod) {
        if (cod != null) {
            for (var _i = 0, _a = this.apps; _i < _a.length; _i++) {
                var app = _a[_i];
                if (app.cod == cod) {
                    return app;
                }
            }
        }
        return null;
    };
    PostTypeForm.prototype.parentTypeForCode = function (cod) {
        if (cod != null) {
            for (var _i = 0, _a = this.postTypes; _i < _a.length; _i++) {
                var type = _a[_i];
                if (type.cod == cod) {
                    return type;
                }
            }
        }
        return null;
    };
    PostTypeForm.prototype.objectTypeForCode = function (cod) {
        if (cod != null) {
            for (var _i = 0, _a = this.objectTypes; _i < _a.length; _i++) {
                var objtype = _a[_i];
                if (objtype.cod == cod) {
                    return objtype;
                }
            }
        }
        return null;
    };
    PostTypeForm.prototype.removeCurrentFromPostTypes = function () {
        var _this = this;
        this.postTypes = this.postTypes.filter(function (postType) {
            return (postType.cod != _this.currentPostType.cod);
        });
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], PostTypeForm.prototype, "register", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], PostTypeForm.prototype, "update", void 0);
    PostTypeForm = __decorate([
        core_1.Component({
            selector: 'posttype-form',
            templateUrl: 'app/components/posttypeform/posttypeform.component.html',
            directives: [router_1.ROUTER_DIRECTIVES, loading_component_1.LoadingIndicator],
            providers: [posttype_service_1.PostTypeService, user_service_1.UserService, core_2.CookieService, objecttype_service_1.ObjectTypeService, http_1.HTTP_PROVIDERS]
        }), 
        __metadata('design:paramtypes', [posttype_service_1.PostTypeService, user_service_1.UserService, router_1.Router, objecttype_service_1.ObjectTypeService])
    ], PostTypeForm);
    return PostTypeForm;
}(loading_component_1.LoadingPage));
exports.PostTypeForm = PostTypeForm;
//# sourceMappingURL=posttypeform.component.js.map