"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require('../../services/user.service');
var http_1 = require('@angular/http');
var navigation_component_1 = require('../navigation/navigation.component');
var loading_component_1 = require('../loading/loading.component');
var posttype_service_1 = require('../../services/posttype.service');
var core_2 = require('angular2-cookie/core');
var application_service_1 = require('../../services/application.service');
var modal_component_1 = require('../modal/modal.component');
var posttypeform_component_1 = require('../posttypeform/posttypeform.component');
var ListPostTypes = (function (_super) {
    __extends(ListPostTypes, _super);
    function ListPostTypes(postService, userService, appservice, router) {
        _super.call(this, false);
        this.postService = postService;
        this.userService = userService;
        this.appservice = appservice;
        this.router = router;
        this.isLoaded = false;
        this.currentApp = null;
        this.typePostToDelete = null;
        this.isLoadingTypes = false;
        this.isTypesLoaded = false;
        this.errorMessage = null;
    }
    ListPostTypes.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.userService.hasAuthenticatedUser()) {
            this.router.navigate(['/login']);
        }
        else {
            this.standby();
            this.appservice.getApps(this.userService.currentSession().currentDeveloper.cod).subscribe(function (apps) {
                _this.ready();
                _this.isLoaded = true;
                _this.apps = apps;
                _this.apps = _this.apps.sort(function (a, b) {
                    return a.cod - b.cod;
                });
                _this.posttypeForm.apps = _this.apps;
            }, function (error) {
                _this.ready();
                _this.showErrorMessage("Houve um erro ao carregar os aplicativos. Verifique sua conexão com a internet e recarregue a página.");
            });
        }
    };
    ListPostTypes.prototype.changeAppAction = function (app) {
        var _this = this;
        // var app = this.apps[index];
        this.startLoadTypes();
        this.postService.postTypesForApp(app.cod).subscribe(function (types) {
            _this.stopLoadTypes();
            _this.appPostTypes = types;
            _this.isTypesLoaded = true;
        }, function (error) {
            _this.stopLoadTypes();
            _this.showErrorMessage("Falha ao carregar tipos de postagem para o aplicativo. Verifique sua conexão com a internet e recarregue a página.");
        });
    };
    ListPostTypes.prototype.startLoadTypes = function () {
        this.isLoadingTypes = true;
        this.standby();
    };
    ListPostTypes.prototype.stopLoadTypes = function () {
        this.isLoadingTypes = false;
        this.ready();
    };
    //@ViewChild(Alert) alert;
    ListPostTypes.prototype.onSubmit = function () {
        // this.modal.title('titulo').text('texto').okButtonTitle('ok').showCancelButton(false).open();
    };
    ListPostTypes.prototype.newPostTypeAction = function () {
        this.posttypeForm.newTypePost();
    };
    ListPostTypes.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    ListPostTypes.prototype.selectTypePost = function (posttype) {
        this.posttypeForm.setUpdatePostForm(posttype.clone(), this.appPostTypes, this.apps);
    };
    // modalClickOkAction(object: any) {
    //     if (object['tag'] == 1){
    //         this.modal.title('Excluindo').text('Excluíndo tipo de postagem...').showCancelButton(false).showOkButton(false);
    //         this.modal.standby();
    //         this.postService.deletePostType(this.userService.currentSession().token, this.typePostToDelete.cod).subscribe(()=>{
    //             this.modal.ready();
    //             this.modal.tag(0).title('Sucesso').text('Tipo de postagem excluído com sucesso.').okButtonTitle('Ok').showOkButton(true).showCancelButton(false);
    //             setTimeout(() =>{
    //                 this.modal.close();
    //             }, 2);
    //         }, error => {
    //             this.modal.ready();
    //             if(error.status == 400){
    //                 this.modal.tag(0).title('Não excluído')
    //                     .text('Um tipo de postagem só pode ser excluído se não houver nenhuma postagem deste tipo. Também não pode existir algum outro tipo de postagem relacionado a ele.')
    //                     .okButtonTitle('Ok').showOkButton(true).showCancelButton(false);
    //             }else if (error.status == 401){
    //                 this.userService.logOut();
    //                 this.router.navigate(['/']);
    //             }else{
    //                 this.modal.tag(0).title('Erro').text('Houve uma falha na comunicação com o server, e não foi possível realizar a operação.').okButtonTitle('Ok').showOkButton(true).showCancelButton(false);
    //             }
    //         });
    //     }else {
    //         this.modal.close();
    //     }
    // }
    // clickDeleteButton(typePost: TypePost){
    //     this.typePostToDelete = typePost;
    //     this.modal.tag(1).title('Confimar').text('Deseja excluir o tipo de postagem \"'+typePost.cod+ '-' + typePost.description + '\"?')
    //                     .cancelButtonTitle('Cancelar').okButtonTitle('Sim').showCancelButton(true).open();
    // }
    ListPostTypes.prototype.registerNewPostType = function (typePost) {
        if (this.currentApp && this.currentApp.cod == typePost.codApp) {
            this.appPostTypes.push(typePost);
        }
    };
    ListPostTypes.prototype.updatePostType = function (typePost) {
        if (this.currentApp && this.currentApp.cod == typePost.codApp) {
            for (var i = 0; i < this.appPostTypes.length; i += 1) {
                if (typePost.cod == this.appPostTypes[i].cod) {
                    this.appPostTypes[i] = typePost;
                }
            }
        }
    };
    __decorate([
        core_1.ViewChild(modal_component_1.Modal), 
        __metadata('design:type', modal_component_1.Modal)
    ], ListPostTypes.prototype, "modal", void 0);
    __decorate([
        core_1.ViewChild(posttypeform_component_1.PostTypeForm), 
        __metadata('design:type', posttypeform_component_1.PostTypeForm)
    ], ListPostTypes.prototype, "posttypeForm", void 0);
    ListPostTypes = __decorate([
        core_1.Component({
            selector: 'list-posttypes',
            templateUrl: 'app/components/listposttypes/listposttypes.component.html',
            providers: [user_service_1.UserService, posttype_service_1.PostTypeService, http_1.HTTP_PROVIDERS, core_2.CookieService, application_service_1.ApplicationService],
            directives: [router_1.ROUTER_DIRECTIVES, navigation_component_1.NavigationComponent, loading_component_1.LoadingIndicator, modal_component_1.Modal, posttypeform_component_1.PostTypeForm]
        }), 
        __metadata('design:paramtypes', [posttype_service_1.PostTypeService, user_service_1.UserService, application_service_1.ApplicationService, router_1.Router])
    ], ListPostTypes);
    return ListPostTypes;
}(loading_component_1.LoadingPage));
exports.ListPostTypes = ListPostTypes;
//# sourceMappingURL=listposttypes.component.js.map