"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require('../../services/user.service');
var router_1 = require('@angular/router');
var core_2 = require('angular2-cookie/core');
var http_1 = require('@angular/http');
var profiletype_service_1 = require('../../services/profiletype.service');
var typeprofile_model_1 = require('../../model/typeprofile.model');
var loading_component_1 = require('../loading/loading.component');
var ProfileTypeForm = (function (_super) {
    __extends(ProfileTypeForm, _super);
    function ProfileTypeForm(profileService, userService, router) {
        _super.call(this, false);
        this.profileService = profileService;
        this.userService = userService;
        this.router = router;
        this.errorMessage = null;
        this.sucessMessage = null;
        this.currentProfileType = new typeprofile_model_1.TypeProfile();
        this.isUpdating = false;
        this.register = new core_1.EventEmitter();
        this.update = new core_1.EventEmitter();
    }
    ProfileTypeForm.prototype.clear = function () {
        this.currentProfileType.description = "";
    };
    ProfileTypeForm.prototype.newProfileType = function () {
        this.isUpdating = false;
        this.currentProfileType = new typeprofile_model_1.TypeProfile();
        this.selectedApp = null;
    };
    ProfileTypeForm.prototype.onSubmit = function () {
        if (this.isUpdating) {
            this.updateProfileType();
        }
        else {
            this.registerProfileType();
        }
    };
    ProfileTypeForm.prototype.registerProfileType = function () {
        var _this = this;
        this.hideMessages();
        this.standby();
        this.currentProfileType.codApp = this.selectedApp.cod;
        this.profileService.registerProfileTypesForApp(this.userService.currentSession().token, this.selectedApp.cod, this.currentProfileType).subscribe(function (cod) {
            _this.ready();
            _this.currentProfileType.cod = cod;
            _this.showSuccessMessage('Tipo de perfil cadastrado com sucesso. O código desse tipo de perfil é \"' + cod + '\". Esse será o código que será usado na criação de perfis de seus usuários.');
            _this.register.emit(_this.currentProfileType.clone());
            _this.newProfileType();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe um tipo de perfil com esse nome cadastrado para esse aplicativo');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar o cadastro. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    ProfileTypeForm.prototype.updateProfileType = function () {
        var _this = this;
        this.hideMessages();
        this.standby();
        this.currentProfileType.codApp = this.selectedApp.cod;
        this.profileService.updateProfileTypeForApp(this.userService.currentSession().token, this.currentProfileType).subscribe(function () {
            _this.ready();
            _this.showSuccessMessage('Tipo de perfil alterado com sucesso.');
            _this.update.emit(_this.currentProfileType.clone());
            _this.newProfileType();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe um tipo de perfil com esse nome cadastrado para esse aplicativo');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar a alteração. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    ProfileTypeForm.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    ProfileTypeForm.prototype.hideErrorMessage = function () {
        this.errorMessage = null;
    };
    ProfileTypeForm.prototype.hideSucessMessage = function () {
        this.sucessMessage = null;
    };
    ProfileTypeForm.prototype.hideMessages = function () {
        this.hideErrorMessage();
        this.hideSucessMessage();
    };
    ProfileTypeForm.prototype.showSuccessMessage = function (message) {
        this.sucessMessage = message;
    };
    ProfileTypeForm.prototype.setUpdatingProfileType = function (profileType) {
        this.currentProfileType = profileType;
        this.isUpdating = true;
        this.selectedApp = this.appForCode(profileType.codApp);
    };
    ProfileTypeForm.prototype.appForCode = function (cod) {
        if (cod != null) {
            for (var _i = 0, _a = this.apps; _i < _a.length; _i++) {
                var app = _a[_i];
                if (app.cod == cod) {
                    return app;
                }
            }
        }
        return null;
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProfileTypeForm.prototype, "register", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ProfileTypeForm.prototype, "update", void 0);
    ProfileTypeForm = __decorate([
        core_1.Component({
            selector: 'profiletype-form',
            templateUrl: 'app/components/profiletypeform/profiletypeform.component.html',
            directives: [router_1.ROUTER_DIRECTIVES, loading_component_1.LoadingIndicator],
            providers: [profiletype_service_1.ProfileTypeService, user_service_1.UserService, core_2.CookieService, http_1.HTTP_PROVIDERS]
        }), 
        __metadata('design:paramtypes', [profiletype_service_1.ProfileTypeService, user_service_1.UserService, router_1.Router])
    ], ProfileTypeForm);
    return ProfileTypeForm;
}(loading_component_1.LoadingPage));
exports.ProfileTypeForm = ProfileTypeForm;
//# sourceMappingURL=profiletypeform.component.js.map