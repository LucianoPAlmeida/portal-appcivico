"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require('../../services/user.service');
var router_1 = require('@angular/router');
var core_2 = require('angular2-cookie/core');
var http_1 = require('@angular/http');
var loading_component_1 = require('../loading/loading.component');
var LoginComponent = (function (_super) {
    __extends(LoginComponent, _super);
    function LoginComponent(service, router) {
        _super.call(this, false);
        this.service = service;
        this.router = router;
        this.errorMessage = null;
        this.successMessage = null;
        this.recoveryEmail = null;
        this.loginMode = true;
    }
    LoginComponent.prototype.onSubmit = function () {
        var _this = this;
        this.hideMessages();
        if (this.loginMode) {
            this.standby();
            this.service.authenticate(this.email, this.password).subscribe(function (data) {
                _this.ready();
                _this.router.navigate(['/principal']);
            }, function (error) {
                _this.ready();
                if (error.status == 401) {
                    _this.errorMessage = 'Falha ao autenticar, e-mail ou senha estão incorretos';
                }
                else {
                    _this.errorMessage = 'Erro de conexão, falta de conexão com a internet ou servidor não está respondendo';
                }
            });
        }
        else {
            this.forgetMyPassAction();
        }
    };
    LoginComponent.prototype.forgetMyPassAction = function () {
        var _this = this;
        this.hideMessages();
        this.standby();
        this.service.forgetPassword(this.recoveryEmail).subscribe(function () {
            _this.ready();
            _this.showSuccessMessage('Uma nova senha foi gerada e enviada para o seu email');
            setTimeout(function () {
                _this.hideMessages();
                _this.loginMode = true;
            }, 2);
        }, function (error) {
            _this.ready();
            if (error.status == 404) {
                _this.showErrorMessage('O e-mail informado não se encontra cadastrado na base.');
            }
            else {
                _this.errorMessage = 'Erro de conexão, falta de conexão com a internet ou servidor não está respondendo';
            }
        });
    };
    LoginComponent.prototype.cancelForgetMyPass = function () {
        this.loginMode = true;
    };
    LoginComponent.prototype.goToForgetMyPass = function () {
        this.loginMode = false;
    };
    LoginComponent.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    LoginComponent.prototype.hideErrorMessage = function () {
        this.errorMessage = null;
    };
    LoginComponent.prototype.hideSucessMessage = function () {
        this.successMessage = null;
    };
    LoginComponent.prototype.hideMessages = function () {
        this.hideErrorMessage();
        this.hideSucessMessage();
    };
    LoginComponent.prototype.showSuccessMessage = function (message) {
        this.successMessage = message;
    };
    LoginComponent = __decorate([
        core_1.Component({
            selector: 'app-login',
            templateUrl: 'app/components/login/login.component.html',
            providers: [user_service_1.UserService, core_2.CookieService, http_1.HTTP_PROVIDERS],
            directives: [router_1.ROUTER_DIRECTIVES, loading_component_1.LoadingIndicator]
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService, router_1.Router])
    ], LoginComponent);
    return LoginComponent;
}(loading_component_1.LoadingPage));
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map