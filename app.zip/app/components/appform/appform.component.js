"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require('../../services/user.service');
var router_1 = require('@angular/router');
var core_2 = require('angular2-cookie/core');
var http_1 = require('@angular/http');
var application_service_1 = require('../../services/application.service');
var application_model_1 = require('../../model/application.model');
var loading_component_1 = require('../loading/loading.component');
var ApplicationForm = (function (_super) {
    __extends(ApplicationForm, _super);
    function ApplicationForm(appService, userService, router) {
        _super.call(this, false);
        this.appService = appService;
        this.userService = userService;
        this.router = router;
        this.errorMessage = null;
        this.sucessMessage = null;
        this.currentApplication = new application_model_1.Application();
        this.isUpdating = false;
        this.register = new core_1.EventEmitter();
        this.update = new core_1.EventEmitter();
    }
    ApplicationForm.prototype.clear = function () {
        this.currentApplication.name = "";
        this.currentApplication.description = "";
    };
    ApplicationForm.prototype.newApp = function () {
        this.isUpdating = false;
        this.currentApplication = new application_model_1.Application();
    };
    ApplicationForm.prototype.onSubmit = function () {
        if (this.isUpdating) {
            this.updateApplication();
        }
        else {
            this.registerApplication();
        }
    };
    ApplicationForm.prototype.registerApplication = function () {
        var _this = this;
        this.hideMessages();
        var codOwner = this.userService.currentSession().currentDeveloper.cod;
        var token = this.userService.currentSession().token;
        this.standby();
        this.appService.registerApp(token, codOwner, this.currentApplication).subscribe(function (appCode) {
            _this.ready();
            _this.currentApplication.cod = appCode;
            _this.showSuccessMessage('Aplicativo cadastrado com sucesso com sucesso. O código do aplicativo é o \"' + appCode + '\".Esse será o código que você irá usar como parâmetro nos endpoints da plataforma.');
            _this.register.emit(_this.currentApplication);
            _this.newApp();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/login']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe um aplicativo cadastrado com esse nome.');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar o cadastro. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    ApplicationForm.prototype.updateApplication = function () {
        var _this = this;
        this.hideMessages();
        var codOwner = this.userService.currentSession().currentDeveloper.cod;
        var token = this.userService.currentSession().token;
        this.standby();
        this.appService.updateApp(token, codOwner, this.currentApplication).subscribe((function (result) {
            _this.ready();
            _this.showSuccessMessage('Aplicativo atualizado com sucesso.');
            _this.update.emit(_this.currentApplication.clone());
            _this.newApp();
        }), function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/login']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe um aplicativo cadastrado com esse nome.');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar a alteração. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    ApplicationForm.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    ApplicationForm.prototype.hideErrorMessage = function () {
        this.errorMessage = null;
    };
    ApplicationForm.prototype.hideSucessMessage = function () {
        this.sucessMessage = null;
    };
    ApplicationForm.prototype.hideMessages = function () {
        this.hideErrorMessage();
        this.hideSucessMessage();
    };
    ApplicationForm.prototype.showSuccessMessage = function (message) {
        this.sucessMessage = message;
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ApplicationForm.prototype, "register", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ApplicationForm.prototype, "update", void 0);
    ApplicationForm = __decorate([
        core_1.Component({
            selector: 'app-form',
            templateUrl: 'app/components/appform/appform.component.html',
            directives: [router_1.ROUTER_DIRECTIVES, loading_component_1.LoadingIndicator],
            providers: [application_service_1.ApplicationService, user_service_1.UserService, core_2.CookieService, http_1.HTTP_PROVIDERS]
        }), 
        __metadata('design:paramtypes', [application_service_1.ApplicationService, user_service_1.UserService, router_1.Router])
    ], ApplicationForm);
    return ApplicationForm;
}(loading_component_1.LoadingPage));
exports.ApplicationForm = ApplicationForm;
//# sourceMappingURL=appform.component.js.map