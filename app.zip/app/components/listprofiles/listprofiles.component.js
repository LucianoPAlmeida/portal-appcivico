"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require('../../services/user.service');
var http_1 = require('@angular/http');
var navigation_component_1 = require('../navigation/navigation.component');
var loading_component_1 = require('../loading/loading.component');
var profiletype_service_1 = require('../../services/profiletype.service');
var core_2 = require('angular2-cookie/core');
var application_service_1 = require('../../services/application.service');
var profiletypeform_component_1 = require('../profiletypeform/profiletypeform.component');
var modal_component_1 = require('../modal/modal.component');
var ListProfiles = (function (_super) {
    __extends(ListProfiles, _super);
    function ListProfiles(profileService, userService, appservice, router) {
        _super.call(this, false);
        this.profileService = profileService;
        this.userService = userService;
        this.appservice = appservice;
        this.router = router;
        this.apps = [];
        this.profileTypes = [];
        this.isLoaded = false;
        this.isProfilesLoaded = false;
        this.currentApp = null;
        this.errorMessage = null;
    }
    ListProfiles.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.userService.hasAuthenticatedUser()) {
            this.router.navigate(['/login']);
        }
        else {
            this.standby();
            this.appservice.getApps(this.userService.currentSession().currentDeveloper.cod).subscribe(function (apps) {
                _this.ready();
                _this.isLoaded = true;
                _this.apps = apps;
                _this.apps = _this.apps.sort(function (a, b) {
                    return a.cod - b.cod;
                });
                _this.profileTypeForm.apps = _this.apps;
            }, function (error) {
                _this.ready();
                _this.showErrorMessage("Houve um erro ao carregar os aplicativos. Verifique sua conexão com a internet e recarregue a página.");
            });
        }
    };
    ListProfiles.prototype.selectProfile = function (profileType) {
        this.profileTypeForm.setUpdatingProfileType(profileType.clone());
    };
    ListProfiles.prototype.newProfileTypeAction = function () {
        this.profileTypeForm.newProfileType();
    };
    ListProfiles.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    ListProfiles.prototype.changeAppAction = function (app) {
        var _this = this;
        this.standby();
        this.profileService.getProfileTypesForApp(app.cod).subscribe(function (profileTypes) {
            _this.ready();
            _this.profileTypes = profileTypes;
            _this.isProfilesLoaded = true;
        }, function (error) {
            _this.ready();
            _this.showErrorMessage('Falha ao carregar tipos de perfil para o aplicativo. Verifique sua conexão com a internet e recarregue a página.');
        });
    };
    ListProfiles.prototype.registerNewProfileType = function (typeProfile) {
        if (this.currentApp && this.currentApp.cod == typeProfile.codApp) {
            this.profileTypes.push(typeProfile);
        }
    };
    ListProfiles.prototype.updateProfileType = function (typeProfile) {
        if (this.currentApp && this.currentApp.cod == typeProfile.codApp) {
            for (var i = 0; i < this.profileTypes.length; i += 1) {
                if (typeProfile.cod == this.profileTypes[i].cod) {
                    this.profileTypes[i] = typeProfile;
                }
            }
        }
    };
    __decorate([
        core_1.ViewChild(navigation_component_1.NavigationComponent), 
        __metadata('design:type', navigation_component_1.NavigationComponent)
    ], ListProfiles.prototype, "navComponent", void 0);
    __decorate([
        core_1.ViewChild(profiletypeform_component_1.ProfileTypeForm), 
        __metadata('design:type', profiletypeform_component_1.ProfileTypeForm)
    ], ListProfiles.prototype, "profileTypeForm", void 0);
    ListProfiles = __decorate([
        core_1.Component({
            selector: 'list-profiles',
            templateUrl: 'app/components/listprofiles/listprofiles.component.html',
            providers: [user_service_1.UserService, profiletype_service_1.ProfileTypeService, http_1.HTTP_PROVIDERS, core_2.CookieService, application_service_1.ApplicationService],
            directives: [router_1.ROUTER_DIRECTIVES, navigation_component_1.NavigationComponent, loading_component_1.LoadingIndicator, profiletypeform_component_1.ProfileTypeForm, modal_component_1.Modal]
        }), 
        __metadata('design:paramtypes', [profiletype_service_1.ProfileTypeService, user_service_1.UserService, application_service_1.ApplicationService, router_1.Router])
    ], ListProfiles);
    return ListProfiles;
}(loading_component_1.LoadingPage));
exports.ListProfiles = ListProfiles;
//# sourceMappingURL=listprofiles.component.js.map