"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require('../../services/user.service');
var router_1 = require('@angular/router');
var core_2 = require('angular2-cookie/core');
var http_1 = require('@angular/http');
var hashtag_service_1 = require('../../services/hashtag.service');
var hashtag_model_1 = require('../../model/hashtag.model');
var loading_component_1 = require('../loading/loading.component');
var HashTagForm = (function (_super) {
    __extends(HashTagForm, _super);
    function HashTagForm(hashtagService, userService, router) {
        _super.call(this, false);
        this.hashtagService = hashtagService;
        this.userService = userService;
        this.router = router;
        this.errorMessage = null;
        this.sucessMessage = null;
        this.currentHashtag = new hashtag_model_1.Hashtag();
        this.isUpdating = false;
        this.register = new core_1.EventEmitter();
        this.update = new core_1.EventEmitter();
    }
    HashTagForm.prototype.clear = function () {
        this.currentHashtag.description = "";
        this.currentHashtag.name = "";
    };
    HashTagForm.prototype.newHashtag = function () {
        this.isUpdating = false;
        this.currentHashtag = new hashtag_model_1.Hashtag();
        this.selectedApp = null;
    };
    HashTagForm.prototype.onSubmit = function () {
        if (this.isUpdating) {
            this.updateHashtag();
        }
        else {
            this.registerHashtag();
        }
    };
    HashTagForm.prototype.registerHashtag = function () {
        var _this = this;
        this.hideMessages();
        this.standby();
        this.currentHashtag.codApp = this.selectedApp.cod;
        this.hashtagService.registerNewHashtag(this.userService.currentSession().token, this.currentHashtag).subscribe(function (cod) {
            _this.ready();
            _this.currentHashtag.cod = cod;
            _this.showSuccessMessage('Hashtag cadastrada com sucesso');
            _this.register.emit(_this.currentHashtag.clone());
            _this.newHashtag();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/login']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe uma hashtag com esse nome cadastrada para esse aplicativo');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar o cadastro da hashtag. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    HashTagForm.prototype.updateHashtag = function () {
        var _this = this;
        this.hideMessages();
        this.standby();
        this.currentHashtag.codApp = this.selectedApp.cod;
        this.hashtagService.updateHashtag(this.userService.currentSession().token, this.currentHashtag).subscribe(function () {
            _this.ready();
            _this.showSuccessMessage('Hashtag alterada com sucesso.');
            _this.update.emit(_this.currentHashtag.clone());
            _this.newHashtag();
        }, function (error) {
            _this.ready();
            if (error.status == 401) {
                _this.userService.logOut();
                _this.router.navigate(['/login']);
            }
            else if (error.status == 400) {
                _this.showErrorMessage('Já existe uma hashtag com esse nome cadastrada para esse aplicativo ou o nome está fora do padrão #hashtag');
            }
            else {
                _this.showErrorMessage('Ocorreu um erro e não foi possível realizar a alteração. Verifique sua conexão com a internet e tente novamente.');
            }
        });
    };
    HashTagForm.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    HashTagForm.prototype.hideErrorMessage = function () {
        this.errorMessage = null;
    };
    HashTagForm.prototype.hideSucessMessage = function () {
        this.sucessMessage = null;
    };
    HashTagForm.prototype.hideMessages = function () {
        this.hideErrorMessage();
        this.hideSucessMessage();
    };
    HashTagForm.prototype.showSuccessMessage = function (message) {
        this.sucessMessage = message;
    };
    HashTagForm.prototype.setUpdatingHashtag = function (hashtag) {
        this.currentHashtag = hashtag;
        this.isUpdating = true;
        this.selectedApp = this.appForCode(hashtag.codApp);
    };
    HashTagForm.prototype.appForCode = function (cod) {
        if (cod != null) {
            for (var _i = 0, _a = this.apps; _i < _a.length; _i++) {
                var app = _a[_i];
                if (app.cod == cod) {
                    return app;
                }
            }
        }
        return null;
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], HashTagForm.prototype, "register", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], HashTagForm.prototype, "update", void 0);
    HashTagForm = __decorate([
        core_1.Component({
            selector: 'hashtag-form',
            templateUrl: 'app/components/hashtagfrom/hashtagform.component.html',
            directives: [router_1.ROUTER_DIRECTIVES, loading_component_1.LoadingIndicator],
            providers: [hashtag_service_1.HashtagService, user_service_1.UserService, core_2.CookieService, http_1.HTTP_PROVIDERS]
        }), 
        __metadata('design:paramtypes', [hashtag_service_1.HashtagService, user_service_1.UserService, router_1.Router])
    ], HashTagForm);
    return HashTagForm;
}(loading_component_1.LoadingPage));
exports.HashTagForm = HashTagForm;
//# sourceMappingURL=hashtagform.component.js.map