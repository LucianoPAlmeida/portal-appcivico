"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var loading_component_1 = require('../loading/loading.component');
var Modal = (function (_super) {
    __extends(Modal, _super);
    function Modal() {
        _super.call(this, false);
        this.showCancelButtonAttr = false;
        this.tagAttr = 0;
        this.showCloseButtonAttr = false;
        this.showOkButtonAttr = true;
        this.clickOk = new core_1.EventEmitter();
        this.clickCancel = new core_1.EventEmitter();
    }
    Modal.prototype.open = function () {
        $('#myModal').modal('show');
    };
    Modal.prototype.close = function () {
        $('#myModal').modal('hide');
    };
    Modal.prototype.text = function (text) {
        this.textAttr = text;
        return this;
    };
    Modal.prototype.title = function (title) {
        this.titleAttr = title;
        return this;
    };
    Modal.prototype.okButtonTitle = function (title) {
        this.okButtonTitleAttr = title;
        return this;
    };
    Modal.prototype.cancelButtonTitle = function (cancelTitle) {
        this.cancelButtonTitleAttr = cancelTitle;
        return this;
    };
    Modal.prototype.showCancelButton = function (show) {
        this.showCancelButtonAttr = show;
        return this;
    };
    Modal.prototype.tag = function (tag) {
        this.tagAttr = tag;
        return this;
    };
    Modal.prototype.showCloseButton = function (show) {
        this.showCloseButtonAttr = show;
        return this;
    };
    Modal.prototype.showOkButton = function (show) {
        this.showOkButtonAttr = show;
        return this;
    };
    // Action
    Modal.prototype.okButton = function () {
        this.clickOk.emit({
            tag: this.tagAttr
        });
    };
    Modal.prototype.cancelButton = function () {
        this.clickCancel.emit({});
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], Modal.prototype, "clickOk", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], Modal.prototype, "clickCancel", void 0);
    Modal = __decorate([
        core_1.Component({
            selector: 'modal-view',
            templateUrl: 'app/components/modal/modal.component.html',
            directives: [loading_component_1.LoadingIndicator]
        }), 
        __metadata('design:paramtypes', [])
    ], Modal);
    return Modal;
}(loading_component_1.LoadingPage));
exports.Modal = Modal;
//# sourceMappingURL=modal.component.js.map