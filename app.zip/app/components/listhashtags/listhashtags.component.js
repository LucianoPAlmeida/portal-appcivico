"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require('../../services/user.service');
var http_1 = require('@angular/http');
var navigation_component_1 = require('../navigation/navigation.component');
var loading_component_1 = require('../loading/loading.component');
var hashtag_service_1 = require('../../services/hashtag.service');
var core_2 = require('angular2-cookie/core');
var application_service_1 = require('../../services/application.service');
var hashtagform_component_1 = require('../hashtagfrom/hashtagform.component');
var modal_component_1 = require('../modal/modal.component');
var ListHashtags = (function (_super) {
    __extends(ListHashtags, _super);
    function ListHashtags(hashtagService, userService, appservice, router) {
        _super.call(this, false);
        this.hashtagService = hashtagService;
        this.userService = userService;
        this.appservice = appservice;
        this.router = router;
        this.apps = [];
        this.hashtags = [];
        this.isLoaded = false;
        this.isHashtagsLoaded = false;
        this.currentApp = null;
        this.errorMessage = null;
    }
    ListHashtags.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.userService.hasAuthenticatedUser()) {
            this.router.navigate(['/login']);
        }
        else {
            this.standby();
            this.appservice.getApps(this.userService.currentSession().currentDeveloper.cod).subscribe(function (apps) {
                _this.ready();
                _this.isLoaded = true;
                _this.apps = apps;
                _this.apps = _this.apps.sort(function (a, b) {
                    return a.cod - b.cod;
                });
                _this.hashtagForm.apps = _this.apps;
            }, function (error) {
                _this.ready();
                _this.showErrorMessage("Houve um erro ao carregar os aplicativos. Verifique sua conexão com a internet e recarregue a página.");
            });
        }
    };
    ListHashtags.prototype.selectHashtag = function (hashtag) {
        this.hashtagForm.setUpdatingHashtag(hashtag.clone());
    };
    ListHashtags.prototype.newHashtagAction = function () {
        this.hashtagForm.newHashtag();
    };
    ListHashtags.prototype.showErrorMessage = function (message) {
        this.errorMessage = message;
    };
    ListHashtags.prototype.changeAppAction = function (app) {
        var _this = this;
        this.standby();
        this.hashtagService.getHashtagsForApp(this.currentApp.cod).subscribe(function (hashtags) {
            _this.ready();
            _this.hashtags = hashtags;
            _this.isHashtagsLoaded = true;
        }, function (error) {
            _this.ready();
            _this.showErrorMessage('Falha ao carregar hashtags para o aplicativo. Verifique sua conexão com a internet e recarregue a página.');
        });
    };
    ListHashtags.prototype.registerHashtag = function (hashtag) {
        if (this.currentApp && this.currentApp.cod == hashtag.codApp) {
            this.hashtags.push(hashtag);
        }
    };
    ListHashtags.prototype.updateHashtag = function (hashtag) {
        if (this.currentApp && this.currentApp.cod == hashtag.codApp) {
            for (var i = 0; i < this.hashtags.length; i += 1) {
                if (hashtag.cod == this.hashtags[i].cod) {
                    this.hashtags[i] = hashtag;
                }
            }
        }
    };
    __decorate([
        core_1.ViewChild(navigation_component_1.NavigationComponent), 
        __metadata('design:type', navigation_component_1.NavigationComponent)
    ], ListHashtags.prototype, "navComponent", void 0);
    __decorate([
        core_1.ViewChild(hashtagform_component_1.HashTagForm), 
        __metadata('design:type', hashtagform_component_1.HashTagForm)
    ], ListHashtags.prototype, "hashtagForm", void 0);
    ListHashtags = __decorate([
        core_1.Component({
            selector: 'list-hashtags',
            templateUrl: 'app/components/listhashtags/listhashtags.component.html',
            providers: [user_service_1.UserService, hashtag_service_1.HashtagService, http_1.HTTP_PROVIDERS, core_2.CookieService, application_service_1.ApplicationService],
            directives: [router_1.ROUTER_DIRECTIVES, navigation_component_1.NavigationComponent, loading_component_1.LoadingIndicator, hashtagform_component_1.HashTagForm, modal_component_1.Modal]
        }), 
        __metadata('design:paramtypes', [hashtag_service_1.HashtagService, user_service_1.UserService, application_service_1.ApplicationService, router_1.Router])
    ], ListHashtags);
    return ListHashtags;
}(loading_component_1.LoadingPage));
exports.ListHashtags = ListHashtags;
//# sourceMappingURL=listhashtags.component.js.map